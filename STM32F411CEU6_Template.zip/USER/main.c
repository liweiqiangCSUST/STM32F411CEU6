#include "stm32f4xx.h"                  // Device header
#include "stm32f4xx_conf.h"
#include "Delay.h"
#include "PC13LED.h"
#include "UserKey.h"


int main()
{
	PC13LED_Init();
	UserKey_Init();
	
	BitAction PC13LED_State = 0;
	
	while(1)
	{
		if (UserKey_Detect() == 1) 
		{
			PC13LED_Switch(PC13LED_State);
			PC13LED_State = !PC13LED_State;
		}
	}

}
