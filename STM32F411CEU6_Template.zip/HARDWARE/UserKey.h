#ifndef  __USERKEY_H
#define  __USERKEY_H

void UserKey_Init(void);
uint8_t UserKey_Detect(void);

#endif
