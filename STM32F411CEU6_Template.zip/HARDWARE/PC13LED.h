#ifndef  __PC13LED_H
#define  __PC13LED_H

void PC13LED_Init(void);
void PC13LED_Switch(BitAction BitVal);

#endif
