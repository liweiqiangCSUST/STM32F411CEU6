#include "stm32f4xx.h"                  // Device header
#include "Delay.h"
#include "OLED.h"

uint16_t i,Num = 0;

int main(void)
{
	OLED_Init();
	
	while (1)
	{
		for(i=0;i<65535;i++)
		{
		OLED_ShowNum(0,0,Num,5,OLED_8X16);
		Num++;
		OLED_Update();
		}
	}
}
