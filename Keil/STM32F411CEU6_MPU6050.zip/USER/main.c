#include "stm32f4xx.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "MPU6050.h"

int16_t AccX,AccY,AccZ,GyroX,GyroY,GyroZ,Temp;
float Ax,Ay,Az,Gx,Gy,Gz;

int main(void)
{
	//初始化
	OLED_Init();
	MPU6050_Init();
	
	//静态字符串
	OLED_ShowString(0,0,"Acc",OLED_8X16);
	OLED_ShowString(45,0,"Gyro",OLED_8X16);
	OLED_ShowString(90,0,"Temp",OLED_8X16);

	//单位	
	OLED_ShowString(30,20,"g",OLED_6X8);
	OLED_ShowString(30,35,"g",OLED_6X8);
	OLED_ShowString(30,50,"g",OLED_6X8);
	OLED_ShowString(75,15+3,"°",OLED_8X16);
	OLED_ShowString(75,30+3,"°",OLED_8X16);
	OLED_ShowString(75,45+3,"°",OLED_8X16);
	OLED_ShowString(115,20-2,"℃",OLED_8X16);
	
	//主循环
	while (1)
	{	//持续获取加速度计、陀螺仪、温度传感器数据
		MPU6050_GetData(&AccX,&AccY,&AccZ,
					&GyroX,&GyroY,&GyroZ,
					&Temp);
		
		//加速度计灵敏度为
		Ax = (double)AccX;
		Ay = (double)AccY/2048*9.8;
		Az = (double)AccZ/2048*9.8;
		Gx = (double)GyroX/16.4;
		Gy = (double)GyroY/16.4;
		Gz = (double)GyroZ/16.4;
		
		
		OLED_ShowFloatNum(0,20,Ax,2,1,OLED_6X8);
		OLED_ShowFloatNum(0,35,Ay,2,1,OLED_6X8);
		OLED_ShowFloatNum(0,50,Az,2,1,OLED_6X8);


		OLED_ShowFloatNum(45,20,Gx,2,1,OLED_6X8);
		OLED_ShowFloatNum(45,35,Gy,2,1,OLED_6X8);
		OLED_ShowFloatNum(45,50,Gz,2,1,OLED_6X8);
		
		OLED_ShowSignedNum(90,18,(Temp-521)/340+35,2,OLED_8X16);
		OLED_Update();
		Delay_ms(1);
	}
}
